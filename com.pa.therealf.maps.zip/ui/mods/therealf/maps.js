cShareSystems.load_pas("TheRealF 2v2, 3vs3, 4vs4", [
    "coui://ui/mods/therealf/systems/bot's_life 3v3 ns.pas",
    "coui://ui/mods/therealf/systems/moon_box 2vs2.pas",
    "coui://ui/mods/therealf/systems/stamford_bridge is falling down 4v4 ns.pas",
    "coui://ui/mods/therealf/systems/drained_nomegatron 4v4.pas",
    "coui://ui/mods/grandhomie/systems/five_teams 2vs2 shared or ffa.pas",
    "coui://ui/mods/grandhomie/systems/water_ball 2vs2.pas"
    ]);
cShareSystems.load_pas("TheRealF XvX or FFA", [
    "coui://ui/mods/therealf/systems/xvx_or ffa orbital war.pas",
    "coui://ui/mods/therealf/systems/wadiya_is a comet!.pas",
    "coui://ui/mods/therealf/systems/stykades_with a twist! [waf] system.pas",
    "coui://ui/mods/therealf/systems/flat_earth society xvx s.pas",
    "coui://ui/mods/therealf/systems/civil_war xvx or ffa.pas",
    "coui://ui/mods/therealf/systems/apx_system.pas",
    "coui://ui/mods/therealf/systems/star_system.pas"
]);
